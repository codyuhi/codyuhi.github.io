// Import the SDK which was downloaded from NPM
const {ApiClient} = require('kashti-sdk');
const prompt = require('prompt-sync')();
process.env.NODE_ENV = 'develop';
// This is disabled because the cert being used is self-signed
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0';

console.log(`-- -- -- -- --
Welcome to the Kashti 2.0 Node Test App!
-- -- -- -- --`);

var baseUrl = prompt('Please enter your Brigade URL: ');

var apiClient = new ApiClient(baseUrl);

let authToken = 'Ko2WSLIQHItTYvWZZYlzQc1UqSUWZhxIipEkiXlQxFKiCTezclrp46r8irkIuA7cBSirWTvrYyRmvz75Klxn1rJciCvgsyZMHRtoZN3b8lUhyiwGlDERMi0MoODJAv5tLxdjPxIb01imvGH2LoYzf5QTYirWlDe6Gg88HfOJdOIhD9Om0PdDkGZwWlPPuWbcabI7KBw9SxlIn8wV5RLoDm5qph66qQMqWkZEVjtaBAbbTIkZexV1wi4cg4y1hzbp';


if(authToken) {
    console.log('Setting Auth Token . . .');
    apiClient.setAuthToken(authToken);
}

apiClient.getProjects();