# node-test-suite
This repo holds code that allows for automated testing to happen for the SDK

Follow these steps to replicate the usage of the node-test-suite app for the Brigade SDK:

1. Clone the repo and `cd` into it using this command:
`git clone https://github.com/kashti-byu-capstone/node-test-suite.git && cd node-test-suite`

2. Install the dependencies for the app with this command:
`npm i`

3. Obtain an Auth Token from your Brigade 2.0 instance by starting your Brigade server and logging in with it.

4. Define the `authToken` string variable in the `index.js` file to be the Auth Token you received from Brigade.  This step can be skipped, but you will receive an authentication error if you skip this step.

5. Start the node app by using this command in the repo's root directory:
`node index.js`

6. You will receive this command line output:
```-- -- -- -- --
Welcome to the Kashti 2.0 Node Test App!
-- -- -- -- --
Please enter your Brigade URL: ```

7. Input the Brigade URL for your Brigade 2.0 instance and type enter.

8. Verify that you receive a response from the Brigade instance in JSON format